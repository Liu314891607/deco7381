<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Verify_email extends CI_Controller {

	public function index(){
        $data['error'] = "";
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$this->load->view('verify_email',$data);
		$this->load->view('template/footer');
	}
    public function reset(){
        $data['error'] = "";
        $this->load->view('template/header');
        $address = $this->input->post('to');
        if(!filter_var($address, FILTER_VALIDATE_EMAIL))
        {
            $data['error']= "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect email address form! </div> ";
            $this->load->view('verify_email',$data);
            $this->load->view('template/footer');
        } 
        else 
        {
        $code = rand(100000,999999);
        $email_data = array(
            'code' => $code,
            'title' => "-- Reset your emial --",
            'to' => $this->input->post('to'),
            'content' => "Your verification code is " .$code
        );
        $this->session->set_userdata($email_data);
        $this->load->model('email_model');
        $this->email_model->send_email();

        $this->load->view('set_email',$data);
        $this->load->view('template/footer');
        }

    }
}
