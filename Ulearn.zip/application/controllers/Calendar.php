<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendar extends CI_Controller {

	public function index() {
		$this->load->model('event_model');
		$prefs = array (
			'show_next_prev' => TRUE,
			'next_prev_url'  => site_url('calendar/index')
		);
		$data['records'] = $this->event_model->get_events();
		$this->load->library('calendar', $prefs);
        $this->load->view('template/header');
        $this->load->view('calendar', $data);
    }

	public function add_events() {
		$username = $this->session->userdata('username');
		$title = $this->input->post('title');
		$date = $this->input->post('date');
		$arr = array(
			'title' => $title,
			'date' => $date,
			'user' => $username
		);
		$this->db->insert('events', $arr);
		$this->load->model('event_model');
		$prefs = array (
			'show_next_prev' => TRUE,
			'next_prev_url'  => site_url('calendar/index')
		);
		$data['records'] = $this->event_model->get_events();
		$this->load->library('calendar', $prefs);
        $this->load->view('template/header');
        $this->load->view('calendar', $data);
	}
}