<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forget extends CI_Controller {

	public function index()
	{
		$data['error'] = "";
		$data['wrong'] = "";
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$this->load->view('forget',$data);
		$this->load->view('template/footer');
	}

	public function user_authority(){
		$this->session->unset_userdata('permission');
		$data['error'] = "";
		$data['wrong'] = "";
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$username = $this->input->post('username'); //getting username
		$concern = $this->input->post('concern'); //getting secrect question
		$answer = $this->input->post('answer'); //getting secrect answer
		if( !$this->user_model->exist($username)){
			$data['error'] = "<div class=\"alert alert-danger\" role=\"alert\"> Username does not exist!</div>";
			$this->load->view('forget',$data);
		} else if( !$this->user_model->security_verify($username,$concern,$answer)) {
			$data['wrong'] = "<div class=\"alert alert-danger\" role=\"alert\"> Question or answer is WRONG! </div>";
			$this->load->view('forget',$data);
		} else {
			$arr = array(
				'username' => $username,
				'permission' => true
			);
			$this->session->set_userdata($arr); // Create a session to save and deliver data
			$this->load->view('reset_password');
		}
		$this->load->view('template/footer');
	}
}
