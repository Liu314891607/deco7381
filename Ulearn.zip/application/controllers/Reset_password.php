<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reset_password extends CI_Controller 
{

	public function index()
	{
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$this->load->view('reset_password');
		$this->load->view('template/footer');
	}

	public function reset()
	{
		$this->load->view('template/header');
		$username = $this->session->userdata('username'); // get username from data.
		$new_password = $this->input->post('password'); // get new password from input.
		if ($this->session->userdata('permission'))
		{
			$this->user_model->reset_password($username,$new_password);
			$this->session->unset_userdata('permission'); //delete permission
			$this->load->view('template/success_register');
		} else {
			$this->load->view('reset_password');
		}
		$this->load->view('template/footer');
	}
}