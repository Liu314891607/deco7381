<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Set_email extends CI_Controller {

	public function index(){
        $data['error'] = "";
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$this->load->view('set_email',$data);
		$this->load->view('template/footer');
	}
    public function set()
    {
        $data['error'] = "";
        $this->load->model('user_model');		//load user model
        $this->load->view('template/header');
        $new_email = $this->session->userdata('to'); // get new email address
        $key = $this->session->userdata('code');  // get the verification code which send to email
        $verification = $this->input->post('verification');  // get user's input verification code
        if($verification == $key) {  // if correct
            $this->user_model->set_email($new_email);  // Reset user's email
            $data['email'] = $new_email;
            $this->session->unset_userdata('to'); // Clear email data from session
            $this->load->view('profile',$data); // Go back to profile
        } else { //if wrong
            $data['error']= "<div class=\"alert alert-danger\" role=\"alert\"> Incorrect verification code! </div> ";
            $this->load->view('set_email',$data);
        }
        $this->load->view('template/footer');
    }

}