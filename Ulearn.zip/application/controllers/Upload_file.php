<!--Reference from https://www.codexworld.com/codeigniter-drag-and-drop-file-upload-with-dropzone/-->
<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class Upload_File extends CI_Controller { 
    function  __construct() { 
        parent::__construct(); 
         
        // Load file model 
        $this->load->model('file'); 
    } 
     
    function index(){ 
		$this->load->view('template/header');
        $data = array(); 
         
        // Get files data from the database 
        $data['files'] = $this->file->getRows(); 
         
        // Pass the files data to view 
        $this->load->view('upload_file/index', $data); 
		$this->load->view('template/footer');
    } 
     
    function dragDropUpload(){ 
        if(!empty($_FILES)){ 
            // File upload configuration 
            $uploadPath = 'uploads/'; 
            $config['upload_path'] = $uploadPath; 
            $config['allowed_types'] = '*'; 
             
            // Load and initialize upload library 
            $this->load->library('upload', $config); 
            $this->upload->initialize($config); 
             
            // Upload file to the server 
            if($this->upload->do_upload('file')){ 
                $fileData = $this->upload->data(); 
                $uploadData['filename'] = $fileData['file_name']; 
                $uploadData['path'] = $this->upload->data('full_path'); 
				$uploadData['username'] = $this->session->userdata('username');
                 
                // Insert files info into the database 
                $insert = $this->file->insert($uploadData); 
            } 
        } 
    } 
}