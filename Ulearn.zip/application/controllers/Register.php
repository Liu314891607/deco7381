<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller 
{

	public function index()
	{
        $data['error'] = "";
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->view('template/header');
		$this->load->view('register',$data);
		$this->load->view('template/footer');
	}

    public function check_register()
    {
        $data['error'] = "";

        $username = $this->input->post('username'); //getting username from register form
		$password = $this->input->post('password'); //getting password from register form
        $concern = $this->input->post('concern'); //getting secrect question from register form
        $answer = $this->input->post('answer'); //getting secrect answer from register form

        if( $this->user_model->exist($username)){                       //if username is unavilable
            $this->load->view('template/header');
            $data['error']= "<div class=\"alert alert-danger\" role=\"alert\"> Username already exists! </div> ";

            $this->load->view('register',$data);

        } else {                                    // Register success
            $sql = "INSERT INTO `users`(`username`, `password`, `concern`, `answer`) VALUES ('$username','$password','$concern','$answer');";
            $this->db->query($sql);
            $user_data = array(
                'username' => $username,
                'logged_in' => true
            );
            $this->session->set_userdata($user_data);   // Auto login
            $this->load->view('template/header');
            $this->load->view('verify_email',$data);  //Go to set email
            echo '<script> alert("Register Success! Please verify your email.")</script>';
        }
        $this->load->view('template/footer');
        
    }
}
