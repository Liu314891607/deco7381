<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Video extends CI_Controller 
{
	public function index()
	{
        $this->load->model('comment_model');
        $data['records'] = $this->comment_model->get_comments();
        $data['success'] = "";
		$this->load->view('template/header'); 
        $this->load->view('video',$data);
        $this->load->view('template/footer');
    }

    public function add_comment() {

		$username = $this->session->userdata('username');
        $content = $this->input->post('content');
		$place = "video";

        if($username == null) {
            $data['error'] = "";
            $this->load->view('template/header'); 
            $this->load->view('login',$data);
        } else {
            $arr = array(
                'content' => $content,
                'place' => $place,
                'user' => $username
                );
            $this->db->insert('comments', $arr);
        }
        $this->load->view('template/header'); 
		$this->load->model('comment_model');
		$data['records'] = $this->comment_model->get_comments();
        $data['success'] = '<br> <h3>Comment success!</h3>';
        $this->load->view('video',$data);
        $this->load->view('template/footer');
	}
}