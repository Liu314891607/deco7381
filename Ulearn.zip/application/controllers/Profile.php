<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller 
{

	public function index(){
        $username = $this->session->userdata('username');
        $sql = "SELECT `email` FROM `users` WHERE `username` = '$username';";
        $this->db->select('email')->from('users')->where('username',$username);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $data['email'] = $query->row()->email;
        }
		$this->load->view('template/header');
		$this->load->view('profile',$data);
		$this->load->view('template/footer');
	}
    
}