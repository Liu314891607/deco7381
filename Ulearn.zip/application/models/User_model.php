<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model{
    // Log in
    public function login($username, $password){
        // Validate
        $this->db->where('username', $username);
	    $this->db->where('password', $password);

        $result = $this->db->get('users');

        if($result->num_rows() == 1){
            return true;
        } else {
            return false;
        }
    }

    // Registern- check whether username is exist. 
    public function exist($username){
        $sql = "SELECT `username` FROM `users` WHERE `username` = '$username';";//Check whether username has been occupied.
        $query = $this->db->query($sql);
        $arr = $query-> result_array();
        if(count($arr) == 0){
            return false;
        } else {
            return true;
        }
    }

    // Forget - check information.
    public function security_verify($username,$concern,$answer){
        $sql = "SELECT `username` FROM `users` WHERE `username` = '$username' AND `concern` = '$concern' AND `answer` = '$answer';";
        $query = $this->db->query($sql);
        $arr = $query-> result_array();
        if(count($arr) == 1){
            return true;
        } else {
            return false;
        }
    }

    // Reset password - reset
    public function reset_password($username,$new_password){
        $sql = "UPDATE `users` SET `password` = '$new_password' WHERE `users`.`username` = '$username';";
        $query = $this->db->query($sql);
    }

    // Profile - check email has right form.
    public function set_email($email){
        $username = $this->session->userdata('username');
        $sql = "UPDATE `users` SET `email` = '$email' WHERE `users`.`username` = '$username';";
        $query = $this->db->query($sql);
    }
    
}
?>
