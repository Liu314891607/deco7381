<!--Open source code from https://www.codexworld.com/codeigniter-event-calendar-jquery/ -->
<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class Comment_model extends CI_Model{ 
    
    public function get_comments() {
        $url = uri_string();
        $place = array_slice(explode('/',$url),-1)[0];
		$this->db->select('content as content, user as user');
        $this->db->from('comments');
		$this->db->where('place', $place);
		$query = $this->db->get();
		return $query->result();
	}

}