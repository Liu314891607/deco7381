<!--Open source code from https://www.codexworld.com/codeigniter-event-calendar-jquery/ -->
<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

class Event_model extends CI_Model{ 
    
    public function get_events() {
		$username = $this->session->userdata('username');
		$this->db->select('title as title, date as date');
        $this->db->from('events');
		$this->db->where('user', $username);
		$query = $this->db->get();
		return $query->result();
	}

}