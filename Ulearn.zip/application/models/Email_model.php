<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model {

	public function send_email()
	{
        $config = array(
            'protocol' => 'smtp',
            'smtp_host' => 'mailhub.eait.uq.edu.au',
            'smtp_port' => 25,
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE,
            'mailtype' => 'html',
            'starttls' =>true,
            'newline' =>"\r\n"
    );
    $this->email->initialize($config);
    $this->email->from('guosen.liu@uqconnect.edu.au', 'Guosen Liu');
    $this->email->to($this->session->userdata('to'));
    $this->email->subject($this->session->userdata('title'));
    $this->email->message($this->session->userdata('content'));
    $this->email->send();

    $this->session->unset_userdata('title');
    $this->session->userdata('content');
    }
}