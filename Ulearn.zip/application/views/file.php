<?php echo form_open_multipart('upload/do_upload');?>
<div class="row justify-content-center">
        <h2>Basic upload</h2>
        <?php echo $error;?>
		<div class="form-group">
            <input class="form-control" type="file" name="userfile" size="20" /> 
        </div>
		<div class="form-group">
            <input class="btn btn-primary" type="submit" value="upload" />
        </div>
        <h2>
            <a href="<?php echo base_url(); ?>upload_file">Advanced Upload</a>
        </h2>
</div>
<?php echo form_close(); ?>
<h3></h3>
<div class="main"> </div>

