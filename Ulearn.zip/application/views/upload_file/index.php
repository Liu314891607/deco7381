<!--Reference from https://www.codexworld.com/codeigniter-drag-and-drop-file-upload-with-dropzone/-->
<script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

<form action="<?php echo base_url('upload_file/dragDropUpload/'); ?>" class="dropzone"></form>
<h4>Uploaded Files</h4>
<?php 
if(!empty($files)){ foreach($files as $row){ 
        $filePath = 'uploads/'.$row["filename"]; 
        $fileMime = mime_content_type($filePath); 
?> 
    <embed src="<?php echo base_url('uploads/'.$row["filename"]); ?>" type="<?php echo $fileMime; ?>" width="350px" height="240px" /> 
<?php 
} }else{ 
?> 
    <p>No file(s) found...</p> 
<?php } ?>