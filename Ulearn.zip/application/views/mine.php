<div style="padding:20px"></div>
<div>
	<h1 style="text-align:center;">My</h2>
</div>
<div class="servers" style="width:100%; height:50%; align-items: center; justify-content: center;">
    <div class="alert alert-dismissible alert-primary">
        <a href="<?php echo base_url(); ?>Profile" class="alert-link">Profile<a>
    </div>
    <div class="alert alert-dismissible alert-primary">
        <a href="<?php echo base_url(); ?>Calendar" class="alert-link">Calendar</a>
    </div>
    <div class="alert alert-dismissible alert-primary">
        <a href="<?php echo base_url(); ?>Position" class="alert-link">Position</a>
    </div>
</div>