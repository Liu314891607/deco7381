<div class="container">
      <div class="col-4 offset-4">
			<?php echo form_open(base_url().'login/check_login'); ?>
				<h2 class="text-center" style="margin-top: 10%">Login</h2>       
					<div class="form-floating mb-3" style="margin-top: 5%">
						<input type="text" class="form-control" id="floatingInput" placeholder="Username" required="required" name="username">
						<label for="floatingInput">Username</label>
					</div>
					<div class="form-floating mb-3" style="margin-top: 5%">
						<input type="password" class="form-control" id="floatingPassword" placeholder="Password" required="required" name="password">
						<label for="floatingPassword">Password</label>
					</div>
					<div class="form-group" style="margin-top: 5%">
						<?php echo $error; ?>
					</div>
					<div class="form-group" style = "text-align:center;margin-top: 5%">
						<button type="submit" class="btn btn-primary" >Log in</button>
					</div>
					<div class="clearfix" style="margin-top: 5%; text-align:center">
						<a href="<?php echo base_url(); ?>register">Register</a> OR
						<a href="<?php echo base_url(); ?>forget" class="float-right">Forgot Password?</a><br>
						<label class="float-left form-check-label"><input type="checkbox" name="remember"> Remember me</label>
					</div>    
			<?php echo form_close(); ?>
	</div>
</div>
