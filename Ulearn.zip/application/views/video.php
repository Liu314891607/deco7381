<?php echo form_open_multipart('video/add_comment'); ?>
<div >
    <div style="width:100%; height:80%; display:flex; flex-direction: row; align-items: center; justify-content: center; text-align:center;">
        <iframe width="1024" height="500" src="https://www.youtube.com/embed/eXYUNrgqWUU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="form-group">
        <label class="form-label mt-4">Comment</label>
        <div>
            <textarea class="form-control" id="exampleTextarea" rows="3" name="content"></textarea>
            <button class="btn btn-primary" type="submit">Add comment</button>
        </div>
        <div>
            <label class="form-label mt-4">All comments</label>
            <?php echo $success; ?>
            <?php foreach($records as $row){
                echo "
                    <br>
					<h5> User: $row->user</h5>
					<p>$row->content</p>
			    ";}
            ?>
        </div>
    </div>
</div>
<?php echo form_close(); ?>
