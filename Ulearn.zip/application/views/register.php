<div class="container">
      <div class="col-4 offset-4">
            <?php echo form_open(base_url().'register/check_register'); ?>
				<h2 class="text-center" style="margin-top: 10%">Register</h2>       
					<div class="form-group" style="margin-top: 5%">
						<label for="exampleSelect1" class="form-label mt-4">Username</label>
						<input type="text" class="form-control" placeholder="Username" required="required" name="username">
					</div>

                    <div class="form-group" style="margin-top: 5%">
						<?php echo $error; ?>
					</div>
            
					<div class="form-group" style="margin-top: 5%">
						<label for="exampleSelect1" class="form-label mt-4">Passwords</label>
						<input type="password" class="form-control" placeholder="Password" required="required" name="password">
					</div>
					
					<div class="form-group">
						<label for="exampleSelect1" class="form-label mt-4">Secret questions</label>
						<select class="form-select" id="exampleSelect1" required="required" name="concern">
							<option>My birthday</option>
							<option>My address</option>
							<option>My student number</option>
							<option>My favorite pet</option>
							<option>My school name</option>
						</select>
					</div>
					
                    <div class="form-group">
						<label for="exampleSelect1" class="form-label mt-4">Security answer</label>
						<input type="text" class="form-control" placeholder="Answer" required="required" name="answer">
					</div>

					<div class="form-group" style = "text-align:center;margin-top: 5%">
						<button type="submit" class="btn btn-primary" >Register</button>
					</div>
            <?php echo form_close(); ?>
	</div>
</div>