<?php echo form_open(base_url().'meet'); ?>
<div>
    <button>Add to Cart</button>
</div>