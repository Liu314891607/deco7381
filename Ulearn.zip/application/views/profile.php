<?php echo form_open(base_url().'profile'); ?>
<div>
    Username: <?php echo $this->session->userdata('username') ?>
</div>
<div>
    E-mail: <?php echo $email;?>
    <a class="btn btn-primary btn-sm" href="<?php echo base_url(); ?>verify_email">Reset</a>
</div>
<?php echo form_close(); ?>