<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>Position</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <style>
    body,
    html,
    #container {
        overflow: hidden;
        width: 100%;
        height: 100%;
        margin: 0;
        font-family: "微软雅黑";
    }
    .info {
        z-index: 999;
        width: auto;
        min-width: 22rem;
        padding: .75rem 1.25rem;
        margin-left: 1.25rem;
        position: fixed;
        top: 1rem;
        background-color: #fff;
        border-radius: .25rem;
        font-size: 14px;
        color: #666;
        box-shadow: 0 2px 6px 0 rgba(27, 142, 236, 0.5);
    }
    </style>
    <script src="//api.map.baidu.com/api?type=webgl&v=1.0&ak=j6ovw8o7eNcfDH3EBH25YK59LA5GdrSH"></script>
</head>
<body>
    
    <div id="container"></div>
</body>
</html>
<script>
var map = new BMapGL.Map("container");
map.centerAndZoom(new BMapGL.Point(116.404, 39.915), 12); // Initialize the map, set the center point coordinates and map level
map.enableScrollWheelZoom(true); // Enable mouse wheel zooming
        var point = new BMapGL.Point(116.331398,39.897445);
        map.centerAndZoom(point,12);
        
        var geolocation = new BMapGL.Geolocation();
        geolocation.getCurrentPosition(function(r){
            if(this.getStatus() == BMAP_STATUS_SUCCESS){
                var mk = new BMapGL.Marker(r.point);
                map.addOverlay(mk);
                map.panTo(r.point);
                alert('Your position is ' + r.point.lng + ',' + r.point.lat);
            }
            else {
                alert('failed' + this.getStatus());
            }        
        });
</script>






<!-- 
<h3>My posotion</h3>
<div id="map"></div>

 
     The `defer` attribute causes the callback to execute after the full HTML
     document has been parsed. For non-blocking uses, avoiding race conditions,
     and consistent behavior across browsers, consider loading using Promises
     with https://www.npmjs.com/package/@googlemaps/js-api-loader.

    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&callback=initMap&v=weekly"
      defer
    ></script>
    </script>
<script>
        function getLocation()
        {
        if (navigator.geolocation)
        {
            navigator.geolocation.getCurrentPosition(showPosition);
        }
        else
        {
            alter("Not support!");
        }
        }
    function showPosition(position)
    {
        return { "lat: "+ position.coords.latitude + ",lng":  + position.coords.longitude } 
    }

    function initMap(){
        var latitude  = position.coords.latitude;
        var longitude = position.coords.longitude;

        var map = new google.maps.Map(document.getElementById("map"), {
            zoom: 12,
            center: { lat: latitude, lng: longitude},
            mapTypeControl: true,
            mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
            position: google.maps.ControlPosition.TOP_CENTER,
            },
            zoomControl: true,
            zoomControlOptions: {
            position: google.maps.ControlPosition.LEFT_CENTER,
            },
            scaleControl: true,
            streetViewControl: true,
            streetViewControlOptions: {
            position: google.maps.ControlPosition.LEFT_TOP,
            },
            fullscreenControl: true,
        });
        var marker = new google.maps.Maker({
            position: { lat: latitude, lng: longitude},
            map: map
        });
    }

    window.initMap = initMap;
</script>
    -->

    
