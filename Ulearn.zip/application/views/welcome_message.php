<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="progress"  onload="restoreScrollPos()">
	<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
</div>
<div>
	<div role="img" style="width:100%; height:70%; background-size: 100%; background-repeat: no-repeat; background-image: url(https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1172&q=80);">
		<div id="container"style="padding:30px;">
		<h1 class="text-muted">Welcome to Ulearn!</h1>
		<div>
			<h2 class="btn btn-outline-success">Start</h2>
		</div>
		</div>
	</div>
</div>
<div class="progress">
	<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
</div>
<div style="padding:20px"></div>
<div>
	<h2 id= "free" style="text-align:center;">Free Resourse</h2>
</div>
<div class="servers" style="width:100%; height:80%; display:flex; flex-direction: row; align-items: center; justify-content: center; text-align:center;">
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Video </p>
		<img src="<?php echo base_url(); ?>assets/img/free.png" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="<?php echo base_url(); ?>video" style="text-decoration:none; ">Learn More</a></button>
	</div>
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Documents</p>
		<img src="<?php echo base_url(); ?>assets/img/Unity.jpg" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="<?php echo base_url(); ?>meet" style="text-decoration:none">Learn More</a></button>
	</div>
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Outside platform</p>
		<img src="<?php echo base_url(); ?>assets/img/basic.jpg" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="https://www.youtube.com/c/unity" style="text-decoration:none">Learn More</a></button>
	</div>
</div>
<div class="progress">
	<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
</div>
<div style="padding:20px"></div>
<div>
	<h2 id="paid" style="text-align:center;">Paid server</h2>
</div>
<div class="servers" style="width:100%; height:80%; display:flex; flex-direction: row; align-items: center; justify-content: center; text-align:center;">
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Meet professor</p>
		<img src="https://images.unsplash.com/photo-1630332457231-3f276a81a0a2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="<?php echo base_url(); ?>meet" style="text-decoration:none">Learn More</a></button>
	</div>
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Live course</p>
		<img src="https://images.unsplash.com/photo-1616596871445-bb8290a7a2c2?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2007" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="<?php echo base_url(); ?>meet" style="text-decoration:none">Learn More</a></button>
	</div>
	<div class="items" style="padding:auto; width:20%; height:80%">
		<p>Large program</p>
		<img src="https://images.unsplash.com/photo-1629904853893-c2c8981a1dc5?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170" alt="" style = "width:90%; height:30%">
		<button type="button" class="btn btn-outline-dark" style="margin-top:5px"><a href="<?php echo base_url(); ?>meet" style="text-decoration:none">Learn More</a></button>
	</div>
</div>
