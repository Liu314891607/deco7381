<?php echo form_open_multipart('calendar/add_events'); ?>
<div class="container" style="display:flex; flex-direction: row; align-items: center; justify-content: center; text-align:center;">
        <?php echo $this->calendar->generate($this->uri->segment(3), $this->uri->segment(4)); ?>
</div>
<div class="progress" style="margin-top:10px">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
</div>
<div style="align-items: center; justify-content: center; text-align:center;">
        <div class="add_event">
                <h3>Add event</h3>
                <div class="form-floating mb-3" style="margin-top: 5%">
                        <input type="text" class="form-control" placeholder="Title" required="required" id="floatingInput" name="title">
                        <label for="floatingInput">Title</label>
                </div>
                <div class="form-floating mb-3" style="margin-top: 5%">
			<input type="text" class="form-control" id="floatingInput" placeholder="Date" required="required" name="date">
			<label for="floatingInput">Date: YYYY-MM-DD</label>
		</div>
                <button class="btn btn-primary" type="submit">ADD</button>
        </div>
        <div class="progress" style="margin-top:10px">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
        </div>
        <div class="event_list">
                <h3>Event list</h3>
                <table class="table table-hover">
                <thead>
                        <tr>
                                <th scope="col">Date</th>
                                <th scope="col">Event</th>
                        </tr>
                </thead>
                <tbody>
                        <?php foreach($records as $row){
                                echo "
				<tr>
					<td>$row->date</td>
					<td>$row->title</td>
				</tr>
			";}
                        ?>
                </tbody>
        </div>
        
</div>

<?php echo form_close(); ?>