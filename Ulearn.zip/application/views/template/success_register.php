<div class="container" style = "margin: 10 auto">
    <div class="col-4 offset-4">
        <div class="card text-white bg-primary mb-3" style="max-width: 20rem;">
        <div class="card-header">Success</div>
        <div class="card-body">
        <h4 class="card-title">You have Your account now!</h4>
        <p class="card-text">Go to login and start you learing!</p>
        </div>
        </div>
    </div>
</div>