<div class="container">
      <div class="col-4 offset-4">
            <?php echo form_open(base_url().'set_email/set'); ?>
				<h2 class="text-center" style="margin-top: 10%">Set Email</h2>
                
					<div class="form-group" style="margin-top: 5%">
						<label for="exampleSelect1" class="form-label mt-4">verification code</label>
						<input type="text" class="form-control" placeholder="Six-digit verification code" required="required" name="verification" min="6" max="6">
					</div>
                    <div class="form-group" style="margin-top: 5%">
						<?php echo $error; ?>
					</div>

					<div class="form-group" style = "text-align:center;margin-top: 5%">
						<button type="submit" class="btn btn-primary" >Set</button>
					</div>
            <?php echo form_close(); ?>
	</div>
</div>